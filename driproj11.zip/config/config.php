<?php $sms_sender_id = 'DRI';//values in this script should be changed by app configureation
$app_domain = $_SERVER['HTTP_HOST'];
$app_name = 'DRI';
$app_slug = 'DRI';
$app_link = $_SERVER['HTTP_HOST'];
$app_domain_root= $_SERVER['HTTP_HOST'];
date_default_timezone_set('Africa/Lagos');

// $img_path = 'http://localhost/';


define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DB_NAME", "applications_db");
define("IMG_PATH", "http://localhost/dri_project/");



?>
